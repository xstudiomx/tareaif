//: Playground - noun: a place where people can play

import UIKit



var rango = 0...100

for var rangos in rango
    
{
    
    var actual = rangos + 1
    
    if (actual % 5)==0{
        
        print("\(actual) Bingo!!!")
        
    }
    
    if((actual % 2) == 0){
        
        print("\(actual) Par!!!")
        
    }
        
    else {
        
        print("\(actual) Impar!!!")
        
    }
    
    if((actual >= 30) && (actual <= 40)){
        
        print("\(actual) Viva Swift!!!")
        
    }
    
}
